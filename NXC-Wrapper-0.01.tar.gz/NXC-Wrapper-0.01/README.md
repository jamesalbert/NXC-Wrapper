NXC-Wrapper
===========

An NXC wrapper written in Perl, designed for the NXT Mindstorm.